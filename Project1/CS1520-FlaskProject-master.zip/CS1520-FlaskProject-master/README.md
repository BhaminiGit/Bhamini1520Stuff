

Name of Project: Assignment 3, CS1520 
My Name: Chris Wood
Pitt ID: crw62@pitt.edu

How To Install Dependencies: 
	run pip3 install -r requirements.txt

How to Run: 
	export FLASK_APP=catering.py , 
	python3 -m flask initdb , 
	python3 -m flask run , 
